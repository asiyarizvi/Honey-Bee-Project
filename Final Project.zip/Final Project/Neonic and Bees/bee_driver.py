from bee_functions import skip_header
from bee_functions import filter_columns
from bee_functions import adjust_file
from bee_functions import list_of_pesticides
from bee_functions import sort_pesticides
from bee_functions import plot_data
import csv
import turtle
import matplotlib.pyplot as plt

def main():
    plot_data('Alabama.csv', 'm', 'Alabama')
    plot_data('Missouri.csv', 'b','Missouri')
    plot_data('Maine.csv', 'g', 'Maine')
    plot_data('Colorado.csv', 'c', 'Colorado')
    plot_data('California.csv', 'k', 'California')  



main()



