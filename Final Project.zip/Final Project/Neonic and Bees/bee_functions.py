import matplotlib.pyplot as plt
import csv
import turtle


# name: skip_header
# inputs: csv file
# outputs: csv file
# purpose: gets rid of the header in a csv file
def skip_header(filename):
    data = []
    line_count = 0
    for row in filename:
        if line_count == 0:
            line_count +=1
        else:
            data.append(row)
            line_count += 1
    return data

# name: filter_columns
# inputs: csv file
# outputs: csv file
# purpose: gets rid of unnecessary info
def filter_columns(filename):
    full_data = []
    for row in filename:
        data = []
        data.append(int(row[1]))
        data.append(int(row[7]))
        data.append(row[8])
        data.append(row[9])
        data.append(float(row[16]))
        full_data.append(data)
    return full_data

# name: list_of_pesticides
# inputs: csv file
# outputs: a list of the pesticides of the rows
# purpose: extracts the pesticides amounts
def list_of_pesticides(filename):
    pesticide_nums = []
    for row in filename:
        pesticide_nums.append(float(row[4]))
    return pesticide_nums
        
     

# name: sort_pesticides
# inputs: csv file
# outputs: csv file
# purpose: organizes rows in file from least amounts of pesticide to most
def sort_pesticides(filename):
    new_data = []
    pesticide_nums = list_of_pesticides(filename)
    count = 0
    while count == 0:
        for row in filename:
            if pesticide_nums == []:
                count +=1
            elif float(row[4]) == float(min(pesticide_nums)):
                new_data.append(row)
                pesticide_nums.remove(float(row[4]))
    return new_data



# name: adjust_file
# inputs: csv file
# outputs: csv file
# purpose: applies the previous functions to adjust a file to our liking
def adjust_file(filename):
    data = []
    with open(filename) as csv_file:
        csv_file = csv.reader(csv_file, delimiter=',')
        for row in csv_file:
            data.append(row)
        data2 = skip_header(data)
        data3 = filter_columns(data2)
        data4 = sort_pesticides(data3)
        return data4



# name: sep_values
# inputs: csv file and a string
# outputs: two lists
# purpose: puts the data in lists for visualizations  
def sep_values(filename, in_color):
    data4 = adjust_file(filename)
    x = []
    y = []
    for row in data4:
        x.append(float(row[4]))
        y.append(row[0])
    return x, y


# name: plot_data
# inputs: csv file and two strings
# outputs: image
# purpose: plots the data in the given color      
def plot_data(filename, in_color, state):
    x, y = sep_values(filename, in_color)
    plt.scatter(x, y, color = in_color)
    plt.xlabel('Amount of Pesticide Used in KG')
    plt.ylabel('Number of Bee Colonies')
    plt.title('Amount of Neonic Pesticide Used vs. Number of Bee Colonies' + ' ' + '(' + state + ')')
    plt.show()    



