'''
Final Project
Food Avalibility
'''

from food_functions import read_food_data
from food_functions import separate_values
import csv
import matplotlib.pyplot as plt

def main():
    frvg_lst = read_food_data('fruitveg.csv')
    nuts_lst = read_food_data('nuts.csv')
    sweets_lst = read_food_data('sweets.csv')
    x, y_fruit, y_vegetables, y_nuts, y_honey = separate_values(frvg_lst, nuts_lst, sweets_lst)
    plt.plot(x, y_fruit, color = 'red', label = 'Fruit')
    plt.plot(x, y_vegetables, c = 'green', label = 'Vegetables')

    plt.xlabel('Year')
    plt.ylabel('Availibilty (in Pounds)')
    plt.title('Availibility of Honey Bee Pollinated Foods: Fruit and Vegetables')
    plt.legend()
    plt.show()
    
    plt.plot(x, y_nuts, color = 'peru', label ='Nuts')
    
    plt.xlabel('Year')
    plt.ylabel('Total Availibilty (in 1,000 pounds)')
    plt.title('Availibility of Honey Bee Pollinated Foods: Tree Nuts') 
    plt.show()

    plt.plot(x, y_honey, c = 'gold', label = 'Honey')
    
    plt.xlabel('Year')
    plt.ylabel('Total Availibilty (in Million pounds)')
    plt.title('Availibility of Honey Bee Pollinated Foods: Honey')
    plt.show()
main()

