'''
Final Project
Food Avalibility
'''
import csv
import matplotlib.pyplot as plt

def read_food_data(filename):
    ''' Function: read_food_data
        Inputs: filename (string)
        Returns: honey_lst (list)
        Does: Reads the inputted CSV file and makes it into a list of values
              separated by comma.
    '''
    with open(filename) as csv_file:
        file = csv_file.readlines()[9:54]
        csv_reader = csv.reader(file, delimiter = ',')
        food_lst = []
        for row in csv_reader:
            if int(row[0]) >= 2000 and int(row[0]) < 2017:
                food_lst.append(row)
        return food_lst

def separate_values(lst1, lst2, lst3):
    ''' Function: separate_values
        Inputs: lst1, lst2 (all lists)
        Returns: x_year, y_fruit, y_vegetables, y_nuts (all lists)
        Does: Takes input lists and separates the info from the rows into
              x and y values. The x value of years remains consistent while
              the y value of availibility for each crop is different.
    '''
    x_year = []
    y_fruit = []
    y_vegetables = []
    y_nuts = []
    y_honey = []
    for row in lst1:
        x_year.append(row[0])
        y_fruit.append(float(row[8]))
        y_vegetables.append(float(row[16]))
    for row in lst2:
        y_nuts.append(float(row[8]))
    for row in lst3:
        y_honey.append(float(row[9]))
    return x_year, y_fruit, y_vegetables, y_nuts, y_honey
