'''
Final Project
Cost of Pollination
'''

from cost_functions import read_pollen_data
from cost_functions import separate_values
from cost_functions import create_csv_name
from cost_functions import get_data
import csv
import matplotlib.pyplot as plt

def main():
    print('Choose the number of the region you would like to see?:',
                       '\n1 = Northeastern',
                       '\n2 = Southeastern',
                       '\n3 = Southern Midwest',
                       '\n4 = North Midwestern',
                       '\n5 = Northwestern + Alaska',
                       '\n67 = Southwestern + Hawaii',
                       '\n*Note: "67" means regions 6 and 7 combined*')
    region_num = int(input())
    csv_name_2017, csv_name_2016, csv_name_2015 = create_csv_name(region_num)
    region_data_2017, region_data_2016, region_data_2015 = get_data(region_num, csv_name_2017, csv_name_2016, csv_name_2015)

    x, y, name = separate_values(region_data_2017)
    plt.scatter(x, y, c = 'green', label = 2017)

    x, y, name = separate_values(region_data_2016)
    plt.scatter(x, y, c = 'blue', label = 2016)
    
    x, y, name = separate_values(region_data_2015)
    plt.scatter(x, y, c = 'orange', label = 2015)

    plt.xlabel('Number of Colonies')
    plt.ylabel('Value of Pollination (per $1,000)')
    plt.title('Region ' + str(region_num))
    plt.suptitle('Correlation between Number of Colonies and Value of Pollination:')
    plt.legend()

    plt.show()
    
main()
