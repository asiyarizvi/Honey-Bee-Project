'''
Final Project
Cost of Pollination
'''
import csv
import matplotlib.pyplot as plt

def read_pollen_data(filename):
    ''' Function: read_pollen_data
        Inputs: filename (string)
        Returns: pollen_lst (list), total_lst (list)
        Does: Reads the inputted CSV file and makes it into a list of values
              separated by commas.
    '''
    with open(filename, encoding="latin1") as csv_file:
        csv_reader = csv.reader(csv_file, delimiter = ',')
        pollen_lst = []
        total_lst = []
        for row in csv_reader:
            if row[2] == 'Total':
                total_lst.append(row[2:8])
            elif row[1] == 'd' and row[3] != '' and row[2] != 'Total':
                pollen_lst.append(row[2:8])
        pollen_lst.sort()
        return pollen_lst, total_lst

def create_csv_name(region_num):
    ''' Function: create_csv_name
        Inputs: region_num (string)
        Returns: csv_name_2017, csv_name_2016, csv_name_2015 (all strings)
        Does: Creates the name of csv files using the input region number.
    '''
    csv_name_2017 = 'Region' + str(region_num) + '_2017.csv'
    csv_name_2016 = 'Region' + str(region_num) + '_2016.csv'
    csv_name_2015 = 'Region' + str(region_num) + '_2015.csv'
    return csv_name_2017, csv_name_2016, csv_name_2015

def get_data(region_num, csv_name_2017, csv_name_2016, csv_name_2015):
    ''' Function: get_data
        Inputs: region_num, csv_name_2017, csv_name_2016, csv_name_2015 (all strings)
        Returns: region_data_2017, region_data_2016, region_data_2015 (all lists)
        Does: Takes the csv name and creates their respective lists.
    '''  
    region_data_2017, totals = read_pollen_data(csv_name_2017)
    region_data_2016, totals = read_pollen_data(csv_name_2016)
    region_data_2015, totals = read_pollen_data(csv_name_2015)
    return region_data_2017, region_data_2016, region_data_2015

def separate_values(lst):
    ''' Function: separate_values
        Inputs: lst (list)
        Returns: x_colonies (list), y_value (list), name_lst (list)
        Does: Takes the list from the csv file and separates values from two
              rows into an x and y list.
    '''
    x_colonies = []
    y_value = []
    count = 0
    name_lst = []
    for row in lst:
        x_colonies.append(float(row[3]))
        y_value.append(float(row[5]))
        name_lst.append(row[0])
    return x_colonies, y_value, name_lst
